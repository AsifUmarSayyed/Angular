import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-result',
  templateUrl: './result.component.html',
  styleUrls: ['./result.component.scss']
})
export class ResultComponent implements OnInit {

  constructor(private http:HttpClient, private router:Router, private activatedRoute:ActivatedRoute) { }
  counter:any=0
  correct:any=0
  dataId:any
  currentTests:any=[]
  options:any=[]
  
  ngOnInit(): void {
    localStorage.setItem("counter",this.counter);
    if( localStorage.getItem("correct")){      
      this.correct=JSON.parse(localStorage.getItem("correct")!)

    }

    this.activatedRoute.params.subscribe(aData=>{
     
      this.dataId=aData
      console.log(this.dataId.id);
      

    })
   


    this.http.get<any>("http://interviewapi.ngminds.com/getQuizData/").subscribe(data=>{
    
      this.currentTests=data.tests[this.dataId.id]
      console.log(this.currentTests);
      this.options=this.currentTests.questions
        })
  }

  next(){
    this.router.navigate([""])
  }

}
