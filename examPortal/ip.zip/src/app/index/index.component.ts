import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-index',
  templateUrl: './index.component.html',
  styleUrls: ['./index.component.scss']
})
export class IndexComponent implements OnInit {
  tests:any=[]
  counter:any=0
  correct:any=0

  constructor(private http:HttpClient, private router:Router) { }

  ngOnInit(): void {
    localStorage.setItem("counter",this.counter);
    localStorage.setItem("correct",this.correct);
    this.http.get<any>("http://interviewapi.ngminds.com/getQuizData").subscribe(data=>{
      console.log(data.tests);
      this.tests=data.tests

      
    })
  }

  questions(i:any){
    this.router.navigate(["question/",i])  


  }

}
