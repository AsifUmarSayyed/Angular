import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-question',
  templateUrl: './question.component.html',
  styleUrls: ['./question.component.scss']
})
export class QuestionComponent implements OnInit {
dataId:any
  currentTests:any=[]
  options:any=[]
  counter:any=0
  correct:any=0
 
  radio: any = document.getElementsByClassName('option'); 
  checkBox: any = document.getElementsByClassName('checkBox'); 

  constructor(private http:HttpClient, private router:Router, private activatedRoute:ActivatedRoute) { }

  ngOnInit(): void {
    if( localStorage.getItem("counter")){      
      this.counter=JSON.parse(localStorage.getItem("counter")!)

    }
    if( localStorage.getItem("correct")){      
      this.correct=JSON.parse(localStorage.getItem("correct")!)

    }
   

    this.activatedRoute.params.subscribe(aData=>{
     
      this.dataId=aData
      console.log(this.dataId.id);
      

    })
    this.http.get<any>("http://interviewapi.ngminds.com/getQuizData/").subscribe(data=>{
    
      this.currentTests=data.tests[this.dataId.id]
      console.log(this.currentTests);
      this.options=this.currentTests.questions
      if(this.counter==this.options.length-1){
        (document.getElementById("next")as HTMLInputElement).style.display = "none";
        (document.getElementById("finish")as HTMLInputElement).style.display = "block";
          
      }

    })

   
  }

  next(){
      if( this.counter<=this.options.length-2)
       {
        this.counter++;
        localStorage.setItem("counter",JSON.stringify(this.counter))
            if(this.counter==this.options.length-1)
            {
             (document.getElementById("next")as HTMLInputElement).style.display = "none";
             (document.getElementById("finish")as HTMLInputElement).style.display = "block";   
            } 
           this.check()
            

        }
      }
  finish(){
    this.router.navigate(["result/",this.dataId.id])
    this.check()
  }

  check(){
    if(this.options[this.counter-1].type=="Multiple-Response"){
      let a=this.options[this.counter-1].correctOptionIndex
     
      if( this.checkBox[a[0]].checked == true &&  this.checkBox[a[1]].checked == true ){
       console.log("good");
       this.correct++;
       localStorage.setItem("correct",JSON.stringify(this.correct))

      }
      
    }
    else{
   
     let a=this.options[this.counter-1].correctOptionIndex
     
     if( this.radio[a].checked == true){
       console.log("good");
       this.correct++
       localStorage.setItem("correct",JSON.stringify(this.correct))

     }
    }

  }
}
